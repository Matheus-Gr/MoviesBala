//
// Created by otavi and mathe on 17/04/2021.
//

#include "sorters.h"

void swap(int *array, int position_1, int position_2) {
    int temp = array[position_1];
    array[position_1] = array[position_2];
    array[position_2] = temp;
}

void quickSort(int *array, int left, int right, int random) {
    /* array = Vetor a ser ordenado
     * left = indice a mais esquerda do vetor (futuramente lado com menores valores)
     * right = indice a mais direita do vetor (futuramente com maiores valores)
     * random = escolher se o pivô sera escolhido randomicamente ou não
     * inserindo 1 para sim e 0 para não
     */
    int MIN_SIZE = 4; //decide em qual sera o tamanho minimo para ser mandado para o insertionSort
    int left_index, piv_index;
    int k = right - left + 1;

    if (k > MIN_SIZE) {
        if (random) {
            srand(time(NULL));
            piv_index = left + rand() % (right - left + 1); //escolhendo um indince aleatoriamente
            printf("%d\n", piv_index);
            swap(array, piv_index, right);  // colocando o pivo no ultimo lugar (o mais a direta)
        }

        int pivot = array[right]; // escolhendo o mais a direita como o pivo
        left_index = (left - 1); // indice do valor mais a esquerda

        for (int j = left; j <= right - 1; j++) {
            if (array[j] < pivot) { //se o valor atual é menor que o pivo, aproxima o 'left_index' para direita
                left_index++;
                swap(array, left_index, j);
                /* coloca o valor atual a esquerda do pivo, organizando o vetor de uma forma
                 * que os valores menores que o pivo ficaram a esquerda do pivo, e os maiores a direita dos menores
                 */
            }
        }
        piv_index = left_index + 1;
        swap(array, piv_index, right); //colocando o pivo entre os valores menores e maiores que ele

        quickSort(array, left, piv_index - 1, random); //organizando os valores menores que o pivo
        quickSort(array, piv_index + 1, right, random); //organizando os valores maiores que o pivo
    } else {
        insertionSort(array, k); //organizando as partes menores com o insertionSort
    }
}

void insertionSort(int *array, int size) {
    for (int i = 1; i <= size - 1; i++) {
        int j = i;
        while (j > 0 && array[j-1] > array[j]){
            /* compara cada valor com o valor a sua esquerda e o vai movendo
             * para esquerda ate que o valor a sua esquerda seja menor que ele, ou o ultima posição
             */
            swap(array,j,j-1);
            j = j - 1;
        }
    }
}

void printArray(int *array, int size) {
    for (int i = 0; i < size; i++) printf("%d ", array[i]);
    printf("\n");
}