#include<stdio.h>
#include "sorters.h"

int main() {
//    int size = 5;
//    int array[] = {8, 1, 5, 7, 6};
    int size;
    printf("Tamanho do vetor\n");
    scanf("%d", &size);
    int array[size];

    printf("Digite os %d valores do vetor\n", size);
    for (int i = 0; i < size; i++) scanf("%d", &array[i]);

    quickSort(array, 0, size - 1, 1);

    printf("Vetor ordenado\n");
    printArray(array, size);
    return 0;
}

