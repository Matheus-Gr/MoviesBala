//
// Created by otavi and mathe on 17/04/2021.
//

#ifndef TP2_SORTERS_H
#define TP2_SORTERS_H

#include <stdlib.h>
#include <time.h>
#include <stdio.h>

void quickSort(int *array, int left, int right, int random);
void swap(int *array, int position_1, int position_2);
void insertionSort(int *array, int size);
void printArray(int *array, int size);

#endif //TP2_SORTERS_H
