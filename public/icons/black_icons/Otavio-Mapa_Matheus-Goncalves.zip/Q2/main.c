#include "arvore.h"

int main() {
    Node *root = TArvore_inicia();
    char *x = malloc(10 * sizeof(char));
    scanf("%s", x);
    infix_Postfix(x);
    Ordem_Matematica(&root, x);
//    Pos_Ordem(root);
    Print2D(root, 0);
    printf("%d", Calculo(root));
    free(root);
    return 0;
}
