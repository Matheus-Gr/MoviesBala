//
// Created by otavi && mathe on 17/04/2021.
//

#include "arvore.h"

Node *Node_Cria(Item x) {
    //aloca um no na arvore
    Node *pAux = (Node *) malloc(sizeof(Node));
    pAux->item = x;
    pAux->pEsq = NULL;
    pAux->pDir = NULL;
    pAux->prev = NULL;
    return pAux;
}

Item Item_Create(char Chave) {
    //basicamente transforma a entrada em uma struct item com conteudo Chave
    Item item;
    item.Chave = Chave;
    return item;
}

void Ordem_Matematica(Node **root, char *expression) {
    /*utiliza a função Eoperador para conferir se é um numero ou um operador e assim explitar os operadores como raiz
     e galho e os numeros como folhas
     */

    int len = strlen(expression);
    Node *aux, *paux, *new_node;
    for (int i = (len - 1); i >= 0; i--) {
        new_node = Node_Cria(Item_Create(expression[i]));
        if (*root == NULL) {
            *root = new_node;
            paux = *root;
            aux=paux;
        }
        else {
            if ((Eoperador(expression[i])) == 1) {
                if (paux->pDir == NULL) {
                    aux = new_node;
                    paux->pDir = aux;
                    aux->prev = paux;
                    paux = aux;
                }
                else if (paux->pEsq == NULL) {
                    aux = new_node;
                    paux->pEsq = aux;
                    aux->prev = paux;
                    paux = aux;
                }
                else {
                    while (paux->pEsq != NULL) {
                        paux = paux->prev;
                    }
                    aux = new_node;
                    paux->pEsq = aux;
                    aux->prev = paux;
                    paux = aux;
                }
            }
            else {
                if (paux->pDir == NULL) {
                    aux = new_node;
                    paux->pDir = aux;
                    aux->prev = paux;
                }
                else if (paux->pEsq == NULL) {
                    aux = new_node;
                    paux->pEsq = aux;
                    aux->prev = paux;
                }
                else {
                    while (paux->pEsq != NULL) {
                        paux = paux->prev;
                    }
                    aux = new_node;
                    paux->pEsq = aux;
                    aux->prev = paux;
                }
            }
        }
    }
}

Node *TArvore_inicia() {
    //inicinializa a arvore com NULL
    return NULL;
}

void Pos_Ordem(Node *p) {
    //impressão pos ordem
    if (p == NULL)
        return;
    Pos_Ordem(p->pEsq);
    Pos_Ordem(p->pDir);
    printf("%c\n", p->item.Chave);
}

int Eoperador(char c) {
    //teste para saber se é operador matematico
    if (c == '+' || c == '-' || c == '*' || c == '/')
        return 1;
    return 0;
}

int Calculo(Node *root) {
    //calcula o valor da arvore
    //arvore vazia
    if (!root)
        return 0;
    //retorna numero int
    if (!root->pEsq && !root->pDir) {
        int num = (int) root->item.Chave - 48;
        return num;
    }
    //valor rota da esquerda
    int pEsq_val = Calculo(root->pEsq);

    //valor rota da direita
    int pDir_Val = Calculo(root->pDir);
    //testes de operadores
    if (root->item.Chave == '+')
        return pEsq_val + pDir_Val;
    else if (root->item.Chave == '-')
        return pEsq_val - pDir_Val;
    else if (root->item.Chave == '*')
        return pEsq_val * pDir_Val;
    else
        return pEsq_val / pDir_Val;
}

void Print2D(Node *root, int size) {
    //percorre a arvore recursivamente imprimindo-a em 2d(basicamente o inorder com \n e " " para separar os nos)
    if (root == NULL)
        return;

    size += 5;

    Print2D(root->pDir, size);

    printf("\n");
    for (int i = 5; i < size; i++)
        printf("   ");
    printf("%c\n", root->item.Chave);

    Print2D(root->pEsq, size);
}

//funçoes para a pilha
struct stack *newStack(int size) {
    struct stack *pt = (struct stack *) malloc(sizeof(struct stack));

    pt->maxsize = size;
    pt->top = -1;
    pt->items = (int *) malloc(sizeof(int) * size);

    return pt;
}

int isEmpty(Stack *stack) {
    return stack->top == -1;
}

int peek(Stack *stack) {
    if (isEmpty(stack))
        return INT_MIN;
    return stack->items[stack->top];
}

int isFull(struct stack *pt) {
    return pt->top == pt->maxsize - 1;
}

void push(struct stack *pt, int x) {
    if (isFull(pt)) {
        printf("Overflow\n");
        exit(EXIT_FAILURE);
    }
    pt->items[++pt->top] = x;
}

int pop(struct stack *pt) {
    if (isEmpty(pt)) {
        printf("Underflow\n");
        exit(EXIT_FAILURE);
    }
    return pt->items[pt->top--];
}

int Superior(char c) {
    //nivel de precedencia dos operadores
    switch (c) {
        case '+':
        case '-':
            return 1;

        case '*':
        case '/':
            return 2;

    }
    return -1;
}

int infix_Postfix(char *exp) {
    //transforma a string de infix pra postfix atraves de u ma pilha para os operadores
    int i, k;
    Stack *stack = newStack(strlen(exp));

    for (i = 0, k = -1; exp[i]; ++i) {
        if (Eoperador(exp[i]) == 0)
            exp[++k] = exp[i];

        else {
            while (!isEmpty(stack) &&
                   Superior(exp[i]) <= Superior(peek(stack)))
                exp[++k] = pop(stack);
            push(stack, exp[i]);
        }

    }
    while (!isEmpty(stack))
        exp[++k] = pop(stack);

    exp[++k] = '\0';
    free(stack->items);
    free(stack);
//    printf( "%s", exp );
}