//
// Created by otavi && mathe on 17/04/2021.
//

#ifndef NOZES_ARVORE_H
#define NOZES_ARVORE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char TChave;

typedef struct {
    TChave Chave;
} Item;
struct node {
    Item item;
    struct node *pEsq, *pDir, *prev;
};
typedef struct node Node;


struct stack {
    int maxsize;
    int top;
    int *items;
};
typedef struct stack Stack;

Node *Node_Cria(Item x);

Item Item_Create(char Chave);

Node *TArvore_inicia();

void Pos_Ordem(Node *p);

int Eoperador(char c);

void Ordem_Matematica(Node **root, char *expression);

int Calculo(Node *root);

void Print2D(Node *root, int size);

struct stack *newStack(int size);

void push(struct stack *pt, int x);

int pop(struct stack *pt);

int peek(Stack *stack);

int isEmpty(Stack *stack);

int Superior(char c);

int infix_Postfix(char *exp);

#endif //NOZES_ARVORE_H
